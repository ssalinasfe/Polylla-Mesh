int count_regions(int *mesh, int i_mesh);
int save_to_mesh(int *mesh, int *poly, int i_mesh, int length_poly, double *r);