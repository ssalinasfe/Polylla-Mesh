/* Definición de constantes. */

/* Triángulos imaginarios. DEBEN ser índices negativos. */
#define TRIANG_BORDER -2
#define NO_ADJ -1

/* Valores booleanos. */
#define FALSE 0
#define TRUE !FALSE

